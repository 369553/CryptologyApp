package Views;

import Base.SystemSettings;
import Control.Actions;
import View.DevDecryptologyScreen;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author SOLAKOĞULLARI
 */
public class MainView {
    GridBagLayout L_MainLayout ;
    JPanel Panel_1st, MovementPanel ;
    CryptScreen Panel_2nd ;
    DecryptScreen Panel_3rd ;
    SpecDecryptScreen Panel_4th ;
    OptionsScreen Panel_5th ;
    JButton Button_1st, Button_2nd, Button_3rd, Button_4th, Button_next, Button_back;
    Actions All_actions ;
    Font Font_General ;
    
    public MainView (){
        getFrame_main().add( getPanel_panel(),BorderLayout.CENTER ) ;
   //     getMovementPanel().setLocation(0, ( ( getFrame_main().getWidth() / 10 ) * 9 ) );
        //getFrame_main().setResizable( false );
        getFrame_main().setVisible( true ) ;
    }

    public GridBagLayout getL_MainLayout() {
        if ( L_MainLayout == null ) {
            L_MainLayout = new GridBagLayout() ;
        }
        return L_MainLayout;
    }

    public void setL_MainLayout(GridBagLayout L_MainLayout) {
        this.L_MainLayout = L_MainLayout;
    }
    
    public JFrame getFrame_main() {
        return MainFrame.getFrame_Main();
    }

    public JPanel getPanel_panel() {
        if ( Panel_1st == null ){
            Panel_1st = new JPanel();
            Panel_1st.setLayout( getL_MainLayout() ) ;
            Add.ADDCOMP ( getPanel_panel(), getButton_1st(), 1, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH );
            Add.ADDCOMP ( getPanel_panel(), getButton_2nd(), 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH );
            Add.ADDCOMP ( getPanel_panel(), getButton_3rd(), 1, 2, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH );
            Add.ADDCOMP ( getPanel_panel(), getButton_4th(), 1, 3, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH );
            Theme.AppTheme( Panel_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
            //getPanel_panel().setBorder(BorderFactory.createTitledBorder("ŞİFRELEYİN"));//ÖNEMLİ BİR ÖZELLİK
        }
        return Panel_1st;
    }

    public void setPanel_panel(JPanel Panel_panel) {
        this.Panel_1st = Panel_panel;
    }

    public JButton getButton_1st() {
        if ( Button_1st == null ){
            Button_1st = new JButton( "ŞİFRELE" );
            Button_1st.addActionListener( getAll_actions( this ) );
            Button_1st.setFont(getFont_General());
            Button_1st.setToolTipText( "Seçtiğiniz algoritmayla yazı şifreleyin" ) ;
        //    Button_1st.setMaximumSize(new Dimension (271, 480) ) ;
        //    Button_1st.setMinimumSize(new Dimension ( 15 ,27 ) ) ;
            Theme.AppTheme( Button_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Button_1st;
    }

    public void setButton_1st( JButton Button_1nd ) {
        this.Button_1st = Button_1nd;
    }

    public JButton getButton_2nd() {
        if ( Button_2nd == null ){
            Button_2nd = new JButton( "ŞİFRE ÇÖZ" );
            Button_2nd.addActionListener( getAll_actions( this ) );
            Button_2nd.setFont(getFont_General());
            Button_2nd.setToolTipText( "Şifrelenmiş metinleri anahtarla çöz" ) ;
            Theme.AppTheme( Button_2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Button_2nd;
    }

    public void setButton_2nd(JButton Button_2nd) {
        this.Button_2nd = Button_2nd;
    }

    public JButton getButton_3rd() {
        if ( Button_3rd == null ){
            Button_3rd = new JButton( "ŞİFRE ÇÖZ (ANAHTARSIZ)" ) ;
            Button_3rd.addActionListener( getAll_actions( this ) );
            Button_3rd.setToolTipText ( "Frekans saldırısıyla basit şifreleri çöz" ) ;
            Theme.AppTheme( Button_3rd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Button_3rd;
    }

    public void setButton_3rd(JButton Button_3rd) {
        this.Button_3rd = Button_3rd;
    }

    public JButton getButton_4th() {
        if ( Button_4th == null ){
            Button_4th = new JButton( "AYARLAR & SEÇENEKLER" );
            Button_4th.addActionListener( getAll_actions( this ) );
            Button_4th.setFont(getFont_General());
            Button_4th.setToolTipText ("Seçenekleri ve ayarları gözden geçirin") ;
            Theme.AppTheme( Button_4th, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Button_4th;
    }

    public void setButton_4th(JButton Button_4th) {
        this.Button_4th = Button_4th;
    }

    public Actions getAll_actions( MainView view ) {
        if ( All_actions == null ) {
            All_actions = new Actions( this );
        }
        return All_actions;
    }

    public void setAll_actions(Actions All_actions) {
        this.All_actions = All_actions;
    }
     public Font getFont_General() {
         if ( Font_General == null ) {
             Font_General = new Font ( "Times New Roman", 1, 14 ) ;
         }
        return Font_General ;
    }

    public void setFont_General(Font Font_General) {
        this.Font_General = Font_General;
    }

    public CryptScreen getPanel_2nd() {
        if ( Panel_2nd == null ) {
            Panel_2nd = new CryptScreen() ;
        }
        return Panel_2nd;
    }

    public void setPanel_2nd(CryptScreen Panel_2nd) {
        this.Panel_2nd = Panel_2nd;
    }

    public DecryptScreen getPanel_3rd() {
        if ( Panel_3rd == null ) {
            Panel_3rd = new DecryptScreen() ;
        }
        return Panel_3rd;
    }

    public void setPanel_3rd(DecryptScreen Panel_3rd) {
        this.Panel_3rd = Panel_3rd;
    }

    public SpecDecryptScreen getPanel_4th() {
        return Panel_4th;
    }

    public void setPanel_4th(SpecDecryptScreen Panel_4th) {
        if ( Panel_4th == null ) {
            Panel_4th = new SpecDecryptScreen() ;
        }
        this.Panel_4th = Panel_4th;
    }

    public OptionsScreen getPanel_5th() {
        if ( Panel_5th == null ) {
            Panel_5th = new OptionsScreen() ;
        }
        return Panel_5th;
    }

    public void setPanel_5th(OptionsScreen Panel_5th) {
        this.Panel_5th = Panel_5th;
    }
    
}
