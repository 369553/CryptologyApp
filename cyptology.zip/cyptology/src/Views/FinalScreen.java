package Views;

import Base.SystemSettings;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author SOLAKOĞULLARI
 */
public class FinalScreen extends JPanel {
    JLabel Label_1st, Label_2nd ;
    private JLabel[] InfsLabel;
    String algorithm ;
    MovementPanel movPan ;
    public FinalScreen ( String algorithm ) {
        this.algorithm = algorithm ;
        setLayout( MainLayout.getMlayout() ) ;
        movPan = (MovementPanel) MainFrame.getFrame_Main().getContentPane().getComponent( 1 ) ;
        movPan.setBackComponent( "CryptScreen" ) ;
        Add.ADDCOMP(this, getLabel_1st(), 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
        Add.ADDCOMP(this, getLabel_2nd(), 0, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
        
    }

    public JLabel getLabel_1st() {
        if ( Label_1st == null ) {
            Label_1st = new JLabel( "ŞİFRELEME BİLGİLERİ:", SwingConstants.CENTER ) ;
            Theme.AppTheme( Label_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_1st;
    }

    public void setLabel_1st(JLabel Label_1st) {
        this.Label_1st = Label_1st;
    }

    public JLabel getLabel_2nd() {
        if ( Label_2nd == null ) {
            Label_2nd = new JLabel( "Algoritma: " + algorithm, SwingConstants.CENTER ) ;
            Theme.AppTheme( Label_2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_2nd;
    }

    public void setLabel_2nd(JLabel Label_2nd) {
        this.Label_2nd = Label_2nd;
    }
    
    public void WriteInfs( String[] infs ) {
        InfsLabel = new JLabel[infs.length] ;
        for ( int i = 0 ; i < infs.length ; i++ ) {
            InfsLabel[i] = new JLabel( infs[i] ) ;
            Add.ADDCOMP( this, InfsLabel[i], 0, i+2, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
            Theme.AppTheme( InfsLabel[i], SystemSettings.getSettings().getCurrentTheme() ) ;
        }
    }

    public MovementPanel getMovPan() {
        return movPan;
    }

    public void setMovPan(MovementPanel movPan) {
        this.movPan = movPan;
    }
    
    
    
}
