package Views;

import Base.DataBase;
import Base.SystemSettings;
import Control.CryptAction;
import Control.MovementsOnKeyboard;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class CryptScreen extends JPanel {
    CryptAction Crypt_Action ;
    MovementsOnKeyboard ListenKey ;
    JButton Button_1st, Button_2nd ;
    JLabel Label_1st ;
    JComboBox Select_Algh;
    JTextArea Open_Text, HintText;
    JScrollPane Scrool_Open_Text, Scrool_Hint_Text;
    GridBagLayout Main_Layout;
    String current_algorithm ;
    ReqCeasar reqCeasar ;
    ReqVigenere reqVigenere ;
    ReqPolybius reqPolybius ;
    MovementPanel movPan ;
    
    //Seçilen algortitma ve o aloritmanın ayarlarına göre girilen text'e müdahale et
    public CryptScreen () {
        setLayout( getMain_Layout() ) ;
        //Add.ADDCOMP(this, getReq_Frame(), 2, 1, 70, this.getHeight(), GridBagConstraints.EAST, GridBagConstraints.BOTH);
        Add.ADDCOMP( this, getSelect_Algh(), 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
        //Add.ADDCOMP(this, getOpen_Text(), 1, 0, 1, 2, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);
        Add.ADDCOMP( this, getScrool_Open_Text(), 0, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        //Add.ADDCOMP( this, getHintPanel(), 1, 0, 2, 2, GridBagConstraints.EAST, GridBagConstraints.WEST ) ;
        Add.ADDCOMP( this, getButton_1st(), 0, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
        Add.ADDCOMP( this, getButton_2nd(), 0, 2, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        //Add.ADDCOMP( this, getScrool_Hint_Text(), 2, 3, 3, 3, GridBagConstraints.EAST, GridBagConstraints.BOTH ) ;
        Theme.AppTheme( this, SystemSettings.getSettings().getCurrentTheme() ) ;
        MainFrame.getFrame_Main().add( getScrool_Hint_Text(), BorderLayout.SOUTH ) ;
        getHintText().setBorder( BorderFactory.createTitledBorder( "İPUCU" ) ) ;
        MainFrame.getFrame_Main().add( getMovPan(), BorderLayout.WEST ) ;
        MainFrame.getFrame_Main().setVisible( true ) ;
    }
    private void Req_Hill () {
        
    }
    private void Req_DES () {
        
    }
    private void Req_AES () {
        
    }
    private void Req_Columnar () {
        
    }
    private void Req_PicketFence () {
        
    }
    private void Req_Polybius () {
        
    }
    private void Req_RSA () {
        
    }
    private void Req_Vigenere () {
        
    }

    public CryptAction getCrypt_Action() {
        if ( Crypt_Action == null ) {
            Crypt_Action = new CryptAction(this);
        }
        return Crypt_Action;
    }

    public void setCrypt_Action(CryptAction Crypt_Action) {
        this.Crypt_Action = Crypt_Action;
    }

    public JComboBox getSelect_Algh() {
        if (Select_Algh==null){
            Select_Algh = new JComboBox(DataBase.getDatabase().getAlghoritms());
            Select_Algh.setSelectedIndex(0);
            //Select_Algh.setBounds(390, 35, 150, 20);
            Select_Algh.setPreferredSize(new Dimension(100,28));
            Select_Algh.addActionListener( getCrypt_Action() ) ;
            Theme.AppTheme( Select_Algh, SystemSettings.getSettings().getCurrentTheme() ) ;
            
        }
        return Select_Algh;
    }

    public void setSelect_Algh(JComboBox Select_Algh) {
        this.Select_Algh = Select_Algh;
    }

    public JTextArea getOpen_Text() {
        if ( Open_Text == null ) {
            Open_Text = new JTextArea(4,6);
            Open_Text.setLineWrap(true);
            Open_Text.setWrapStyleWord(true);
            Theme.AppTheme( Open_Text, SystemSettings.getSettings().getCurrentTheme() ) ;
        //    Open_Text.setSelectedTextColor(Color.decode( SystemSettings.getSettings().getCurrentTheme().getButtonTextColor() ) ) ;
        //    Open_Text.setSelectionColor(Color.decode( SystemSettings.getSettings().getCurrentTheme().getButtonColor() ) ) ;
            Open_Text.addKeyListener( getListenKey() ) ;
        }
        return Open_Text;
    }

    public JTextArea getHintText() {
        if ( HintText == null ) {
            HintText = new JTextArea( 4, 6 ) ;
            HintText.setLineWrap(true);
            HintText.setWrapStyleWord(true);
            Theme.AppTheme( HintText, SystemSettings.getSettings().getCurrentTheme() ) ;
            HintText.setBackground(Color.decode(SystemSettings.getSettings().getCurrentTheme().getBackgroundColor() ) ) ;
            HintText.setEditable( false ) ;
            setHints() ;
            
        }
        return HintText;
    }

    public void setHintText(String HintText) {
        this.HintText.setText( HintText ) ;
    }
    
    public void setOpen_Text(JTextArea Open_Text) {
        this.Open_Text = Open_Text;
    }

    public GridBagLayout getMain_Layout() {
        if ( Main_Layout == null ) {
            Main_Layout = new GridBagLayout() ;
        }
        return Main_Layout;
    }

    public void setMain_Layout(GridBagLayout Main_Layout) {
        this.Main_Layout = Main_Layout;
    }

    public JScrollPane getScrool_Open_Text() {
        if ( Scrool_Open_Text == null ) {
            Scrool_Open_Text = new JScrollPane(getOpen_Text(), JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            Theme.AppTheme( Scrool_Open_Text, SystemSettings.getSettings().getCurrentTheme() ) ;
            //ARAŞTIR = SCROOL PANE'ın rengini değiştirmek
        }
        return Scrool_Open_Text;
    }

    public void setScrool_Open_Text(JScrollPane Scrool_Open_Text) {
        this.Scrool_Open_Text = Scrool_Open_Text;
    }

    public JScrollPane getScrool_Hint_Text() {
        if ( Scrool_Hint_Text == null ) {
            Scrool_Hint_Text = new JScrollPane( getHintText(), JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED ) ;
        }
        return Scrool_Hint_Text;
    }

    public void setScrool_Hint_Text(JScrollPane Scrool_Hint_Text) {
        this.Scrool_Hint_Text = Scrool_Hint_Text;
    }

    public JButton getButton_1st() {
        if ( Button_1st == null ) {
            Button_1st = new JButton ( "Ayarlama" ) ;
           // Button_1st.setFont( new Font( "Times New Roman", Font.ITALIC, 8 ) ) ;
            Button_1st.addActionListener( getCrypt_Action() ) ;
            Theme.AppTheme(Button_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        } 
        return Button_1st;
    }

    public void Button_1st(JButton Button_1st) {
        this.Button_1st = Button_1st;
    }

    public JButton getButton_2nd() {
        if ( Button_2nd == null ) {
            Button_2nd = new JButton( "ŞİFRELE" ) ;
            Button_2nd.addActionListener( getCrypt_Action() ) ;
            Theme.AppTheme( Button_2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Button_2nd;
    }

    public void setButton_2nd(JButton Button_2nd) {
        this.Button_2nd = Button_2nd;
    }
    
    public void changeReqPanel () {
        switch ( getCurrent_algorithm() ) {
            case "CEASAR": {
                MainFrame.getFrame_Main().add( getReqCeasar( ), BorderLayout.EAST ) ; break ; }
            case "VIGENERE": {
                MainFrame.getFrame_Main().add ( getReqVigenere(), BorderLayout.EAST ) ; break ; }
        }
    }

    public String getCurrent_algorithm() {
        if ( current_algorithm == null ) {
            current_algorithm = "CEASAR" ;
        }
        return current_algorithm;
    }

    public void setCurrent_algorithm(String current_algorithm) {
        this.current_algorithm = current_algorithm;
    }

    public ReqCeasar getReqCeasar() {
        if ( reqCeasar == null ) {
            reqCeasar = new ReqCeasar() ;
        }
        return reqCeasar;
    }

    public void setReqceasar(ReqCeasar reqCeasar) {
        this.reqCeasar = reqCeasar;
    }
    
    public ReqVigenere getReqVigenere() {
        if ( reqVigenere == null  ) {
            reqVigenere = new ReqVigenere() ;
        }
        return reqVigenere ;
    }

    public MovementPanel getMovPan() {
        if ( movPan == null ) {
            movPan = new MovementPanel( "MainView" ) ;
        }
        return movPan;
    }

    public void setMovPan(MovementPanel movPan) {
        this.movPan = movPan;
    }
    
    public void refreshReq () {
        MainFrame.getFrame_Main().getContentPane().remove( 3 ) ;
        changeReqPanel() ;
   //     MainFrame.getFrame_Main().remove(  ) ;
    }

    public MovementsOnKeyboard getListenKey() {
        if ( ListenKey == null ) {
            ListenKey = new MovementsOnKeyboard( this ) ;
        }
        return ListenKey;
    }

    public void setListenKey(MovementsOnKeyboard ListenKey) {
        this.ListenKey = ListenKey;
    }
    
    public void setHints() {
        this.setHintText( DataBase.getDatabase().getHints( this.getSelect_Algh().getSelectedItem().toString(), false ) ) ;
    //    MainFrame.getFrame_Main().setVisible( true ) ;
    }
    
    public ReqPolybius ReqPolybius () {
        if ( reqPolybius == null ) {
            reqPolybius = new ReqPolybius() ;
        }
        return reqPolybius ;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
