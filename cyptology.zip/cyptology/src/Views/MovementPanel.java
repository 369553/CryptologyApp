/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;

import Base.SystemSettings;
import Control.BackAction;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author SOLAKOĞULLARI
 */
public class MovementPanel extends JPanel{
    Icon backButtonIcon, backButtonIcon2 ;
    JButton Button_back ;
    String backComponentName ;
    BackAction BackActions ;
    
    public MovementPanel ( String backComponentName ) {
        setLayout( MainLayout.getMlayout() ) ;
        this.backComponentName = backComponentName ;
        Add.ADDCOMP(this, getButton_back(), 0, 0, 1, 1, GridBagConstraints.WEST, GridBagConstraints.NONE ) ;
        Theme.AppTheme( this, SystemSettings.getSettings().getCurrentTheme() ) ;
        
    }

    public MovementPanel getMovementPanel() {
        return this;
    }
    
    public JButton getButton_back() {
        if ( Button_back == null ) {
            Button_back = new JButton() ;
            Button_back.setBorderPainted(false);
            backButtonIcon = new ImageIcon(getClass().getResource("Other_icons/01BackButton.png")) ;
            Button_back.setIcon( backButtonIcon ) ;
            Button_back.setContentAreaFilled(false);
            Button_back.setFocusPainted(false);
            Button_back.setBorderPainted(false);
            Theme.AppTheme( Button_back, SystemSettings.getSettings().getCurrentTheme() ) ;
            if ( SystemSettings.getSettings().getThemeName().equals( "Dark" ) ) {
                backButtonIcon2 = new ImageIcon(getClass().getResource("Other_icons/02BackButton.png")) ;
                Button_back.setIcon( backButtonIcon2 ) ;
            }
            Button_back.addActionListener( getBackActions() ) ;
        }
        return Button_back;
    }

    public void setButton_back(JButton Button_back) {
        this.Button_back = Button_back;
    }

    public String getBackComponentName() {
        return backComponentName ;
    }

    public void setBackComponent(String backComponentName) {
        this.backComponentName = backComponentName ;
    }

    public BackAction getBackActions() {
        if ( BackActions == null ) {
            BackActions = new BackAction( this ) ;
        }
        return BackActions;
    }

    public void setBackActions(BackAction BackActions) {
        this.BackActions = BackActions;
    }
    
    
    
}
