package Views;

import Base.DataBase;
import Base.SystemSettings;
import Control.Actions;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JFileChooser;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import java.awt.LayoutManager;
import javax.swing.Box;
import javax.swing.BoxLayout;
import java.io.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
/**
 *
 * @author SOLAKOĞULLARI
 */
public class OptionsScreen extends JPanel {
    JLabel Label_1st, Label_2nd, Label_3rd, Label_4th, Label_5th;
    JButton Button_1st, Button_2nd ;
    JCheckBox CheckBox_1st, CheckBox_2nd ;
    JComboBox ComboBox_1st, ComboBox_2nd ;
    String[] Languages, Colors ;
    GridBagLayout L_Main ;
    File Report_File ;
    String path, filetype, current_path ;
    Actions All_Actions ;
    JFileChooser chooser;
    MovementPanel movPan ;
    
    public OptionsScreen () {
        this.setLayout( null ) ;
        this.setBounds(61, 11, 81, 140) ;
        this.setLayout( getL_Main() ) ;
        //this.setBackground( Color.decode (SystemSettings.getSettings().getCurrentTheme().getBackgroundColor() ) ) ;
        //this.setForeground( Color.decode (SystemSettings.getSettings().getCurrentTheme().getTextColor() ) ) ;
        //Theme.AppTheme( this, new Theme( SystemSettings.getThemeName() ) ) ;
        //System.out.println("this.getClass().getName() = " + super.toString() ) ;
        Add.ADDCOMP(this, getLabel_1st(), 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP(this, getComboBox_1st(), 2, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP(this, getLabel_2nd(), 1, 2, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP(this, getCheckBox_1st(), 2, 2, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP(this, getLabel_3rd(), 1, 3, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        //Bu yöntem güvenli ve kaliteli değil//Add.insets = new Insets (10,10,10,10);
        Add.ADDCOMP(this, getButton_2nd(), 2, 3, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP(this, getLabel_4th(), 1, 4, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP(this, getComboBox_2nd(), 2, 4, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP(this, getButton_1st(), 1, 6, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        MainFrame.getFrame_Main().add( getMovPan(), BorderLayout.WEST ) ;
        Theme.AppTheme( this, SystemSettings.getSettings().getCurrentTheme() ) ;
    }

    public GridBagLayout getL_Main() {
        if ( L_Main == null ) {
            L_Main = new GridBagLayout();
        }
        return L_Main;
    }

    public void setL_Main(GridBagLayout L_Main) {
        this.L_Main = L_Main;
    }

    public JLabel getLabel_1st() {
        if ( Label_1st == null ) {
            Label_1st = new JLabel( "DİL: " ) ;
            Theme.AppTheme(Label_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_1st;
    }

    public void setLabel_1st(JLabel Label_1st) {
        this.Label_1st = Label_1st;
    }

    public JLabel getLabel_2nd() {
        if ( Label_2nd == null ) {
            Label_2nd = new JLabel( "Raporla: " ) ;
            Theme.AppTheme(Label_2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_2nd;
    }

    public void setLabel_2nd(JLabel Label_2nd) {
        this.Label_2nd = Label_2nd;
    }

    public JLabel getLabel_3rd() {
        if ( Label_3rd == null ) {
            Label_3rd = new JLabel( "Rapor kaydetme yeri: " ) ;
            Theme.AppTheme(Label_3rd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_3rd;
    }

    public void setLabel_3rd(JLabel Label_3rd) {
        this.Label_3rd = Label_3rd;
    }

    public JLabel getLabel_4th() {
        if ( Label_4th == null ) {
            Label_4th = new JLabel( "Tema : " ) ;
            Theme.AppTheme(Label_4th, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Label_4th;
    }

    public void setLabel_4th(JLabel Label_4th) {
        this.Label_4th = Label_4th;
    }

    public JCheckBox getCheckBox_1st() {
        if ( CheckBox_1st == null ) {
            CheckBox_1st = new JCheckBox() ;
            CheckBox_1st.addActionListener( getAll_Actions() ) ;
            Theme.AppTheme(CheckBox_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return CheckBox_1st;
    }

    public void setCheckBox_1st(JCheckBox CheckBox_1st) {
        this.CheckBox_1st = CheckBox_1st;
    }

    public JComboBox getComboBox_1st() {
        if ( ComboBox_1st == null ) {
            ComboBox_1st = new JComboBox( getLanguages() ) ;
            ComboBox_1st.setSize(new Dimension (40, 70 ) ) ;
            ComboBox_1st.setMaximumSize(new Dimension ( 105, 70 ) ) ;
            ComboBox_1st.setMinimumSize(new Dimension ( 40, 30 ) ) ;
            Theme.AppTheme(ComboBox_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return ComboBox_1st;
    }

    public JButton getButton_1st() {
        if ( Button_1st == null ) {
            Button_1st = new JButton( "KAYDET" ) ;
            Button_1st.addActionListener( getAll_Actions() ) ;
            Theme.AppTheme(Button_1st, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Button_1st;
    }

    public void setButton_1st(JButton Button_1st) {
        this.Button_1st = Button_1st;
    }

    public JButton getButton_2nd() {
        if ( Button_2nd == null ) {
            Button_2nd = new JButton( "Gözat" ) ;
            Button_2nd.addActionListener( getAll_Actions() ) ;
            Button_2nd.setEnabled( false ) ;
            Theme.AppTheme(Button_2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return Button_2nd;
    }

    public void setButton_2nd(JButton Button_2nd) {
        this.Button_2nd = Button_2nd;
    }

    public void setComboBox_1st(JComboBox ComboBox_1st) {
        this.ComboBox_1st = ComboBox_1st;
    }

    public JComboBox getComboBox_2nd() {
        if ( ComboBox_2nd == null ) {
            ComboBox_2nd = new JComboBox( /*getColors()*/ ) ;
            ComboBox_2nd.setModel( getcolormodel() ) ;
            ComboBox_2nd.setRenderer(new ListCellRender() ) ;
            ComboBox_2nd.setSelectedIndex(0);
            Theme.AppTheme(ComboBox_2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
            /*ComboBox_1st.setSize(new Dimension (40, 70 ) ) ;
            ComboBox_1st.setMaximumSize(new Dimension ( 105, 70 ) ) ;
            ComboBox_1st.setMinimumSize(new Dimension ( 40, 30 ) ) ;*/
        }
        return ComboBox_2nd;
    }

    public void setComboBox_2nd(JComboBox ComboBox_2nd) {
        this.ComboBox_2nd = ComboBox_2nd;
    }

    public String[] getLanguages() {//DATABASE'den al
        if ( Languages == null ) {
            Languages = new String[] {"TÜRKÇE", "ENGLISH"};
        }
        return Languages;
    }

    public void setLanguages(String[] Languages) {
        this.Languages = Languages;
    }

    public String[] getColors() {//DATABASE'den al
        if ( Colors == null ) {
            Colors = DataBase.getDatabase().getThemes() ;
        }
        return Colors;
    }

    public void setColors(String[] Colors) {
        this.Colors = Colors;
    }

    public JFileChooser getChooser() {
        if ( chooser == null ) {
            current_path = "/Desktop";//????
            chooser = new JFileChooser( current_path ) ;
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.addActionListener( getAll_Actions() ) ;
            chooser.setAcceptAllFileFilterUsed( false ) ;
            Theme.AppTheme(chooser, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return chooser;
    }

    public void setChooser(JFileChooser chooser) {
        this.chooser = chooser;
    }
    
    public void openChooser () {
        getChooser().showDialog(this, "Klasörü seç" ) ;
    }

    public Actions getAll_Actions() {
        if ( All_Actions == null ) {
            All_Actions = new Actions( this ) ;
        }
        return All_Actions;
    }

    public void setAll_Actions(Actions All_Actions) {
        this.All_Actions = All_Actions;
    }
    
    DefaultComboBoxModel getcolormodel(){
        DefaultComboBoxModel model= new DefaultComboBoxModel();
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/01Standard.png")),"Standard"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/02Alternative.png")),"Alternative"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/03Blue.png")),"Blue"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/04Purple.png")),"Purple"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/05Red.png")),"Red"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/06Gold.png")),"Gold"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/07Special.png")),"Special"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/08Dark.png")),"Dark"));
        return model;
}

    public MovementPanel getMovPan() {
        if ( movPan == null ) {
            movPan = new MovementPanel( "MainView" ) ;
        }
        return movPan;
    }

    public void setBackAct( MovementPanel movPan ) {
        this.movPan = movPan;
    }

}