package Views;

import Base.SystemSettings;
import Control.CryptAction;
import Control.MovementsOnKeyboard;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ReqVigenere extends JPanel{
    JLabel label1st, label2nd ;
    JTextField TextField1st ;
    JComboBox CBox_Lang ;
    MovementsOnKeyboard listenKey ;
    CryptAction cryptAct ;
    
    public ReqVigenere () {
        setLayout( MainLayout.getMlayout() ) ;
        Add.ADDCOMP( this, getLabel1st(), 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
        Add.ADDCOMP( this, getTextField1st(), 0, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE ) ;
        Add.ADDCOMP( this, getLabel2nd(), 0, 2, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        Add.ADDCOMP( this, getCBox_Lang(), 0, 4, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH ) ;
        this.setBorder( BorderFactory.createTitledBorder( "VIGENERE" ) ) ;
        Theme.AppTheme(this, SystemSettings.getCurrentTheme() ) ;
        
    }

    public JLabel getLabel1st() {
        if ( label1st == null ) {
            label1st = new JLabel( "Anahtar metin: " ) ;
            Theme.AppTheme(label1st, SystemSettings.getCurrentTheme() ) ;
        }
        return label1st;
    }

    public void setLabel1st(JLabel label1st) {
        this.label1st = label1st;
    }

    public JTextField getTextField1st() {
        if ( TextField1st == null ) {
            TextField1st = new JTextField() ;
            TextField1st.setPreferredSize( new Dimension (120, 28) ) ;
            TextField1st.setToolTipText( "Alfabe seçiminde anahtar metin kullanılır" ) ;
            TextField1st.addKeyListener( getListenKey() );
            Theme.AppTheme(TextField1st, SystemSettings.getCurrentTheme() ) ;
        }
        return TextField1st;
    }

    public void setTextField1st(JTextField TextField1st) {
        this.TextField1st = TextField1st;
    }
    
    
   //getOpenCubePanel

    public MovementsOnKeyboard getListenKey() {
        if ( listenKey == null ) {
            listenKey = new MovementsOnKeyboard( this ) ;
        }
        return listenKey;
    }

    public void setListenKey(MovementsOnKeyboard listenKey) {
        this.listenKey = listenKey;
    }

    public JLabel getLabel2nd() {
        label2nd = new JLabel ( "Alfabe: " ) ;
        Theme.AppTheme(label2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        return label2nd;
    }

    public void setLabel2nd(JLabel label2nd) {
        this.label2nd = label2nd;
    }

    public JComboBox getCBox_Lang() {
        if ( CBox_Lang == null ) {
            CBox_Lang = new JComboBox( new String[]{ "TÜRKÇE", "ENGLISH" } ) ;
            CBox_Lang.addActionListener( getCryptAct() ) ;
            Theme.AppTheme(label2nd, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return CBox_Lang;
    }

    public void setCBox_Lang(JComboBox CBox_Lang) {
        this.CBox_Lang = CBox_Lang;
    }
    
    public CryptAction getCryptAct () {
        if ( cryptAct == null ) {
            cryptAct = new CryptAction ( this ) ;
        }
        return cryptAct ;
    }
}
