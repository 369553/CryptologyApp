/* @author MEHMET AKİF SOLAK */
package Base;

import Algorithms.Alphabet;
import Algorithms.Ceasar;
import Algorithms.Columnar;
import Algorithms.DES;
import Algorithms.Hill;
import Algorithms.PicketFence;
import Algorithms.Polybius;
import Algorithms.Vigenere;
import Views.MainView;
import javax.swing.JOptionPane;

public class Cyptology {
    
    public static void main(String[] args) {
        Alphabet turkce, english;
        DataBase.getDatabase();
        //MainView view;
        //view = new MainView ();
        turkce = new Alphabet ((short) 29, "TÜRKÇE");
        english = new Alphabet ((short) 26, "ENGLISH");
        MainView uii = new MainView();
        
/*CRYPT DES*/ 
//        boolean [] key = {true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false};
//        DES cipher_by_DES = new DES(key);
//        String sifreli = cipher_by_DES.crypting("aaaşb") ;
        //String acik = cipher_by_DES.decrypting(sifreli) ;
        /*DENEME for int - char converting int a = 22998;
        char c = (char) a;
        System.out.println("c : " + c + " saysısal a = " + a);
        a = (int) c;
        System.out.println("sayısal a = " + a);*/
//        System.out.println("\nsifreli: " + sifreli/* + "\n" + "acik: " + acik*/ ) ;
       // System.out.println("acık : aaab , değişken acık : " + acık + " sifreli : " + sifreli ) ;
        //cipher_by_DES.fonk_deneme('ğ'); // ş = 351 , ü = 252, ç = 231 ı = 305 ğ = 287
       // int o = (int) 'a' ;
       // int o2 = (int) 'b' ;
        //String message = "abcd" ;
       // boolean [] value = cipher_by_DES.convert_to_bits_for_char(o);
        //boolean [] value2 = cipher_by_DES.convert_to_bits_for_char(o2);
        //System.out.println("value.length : " + value.length);
        //System.out.println("value2.length : " + value2.length);
        //boolean [] [] value3;
      //  value3 = new boolean [2] [32] ;
        //value3 [0] = value ;
      //  value3 [1] = value2 ;
      //  boolean [] merge_Value = cipher_by_DES.merge(value3);
     // DES ui = new DES("aaab");
    //  boolean [] kl ;
    //  kl = new boolean [64] ;
    //  kl [0] = true ; kl [1] = true ; kl [2] = true ; kl [3] = true ; kl [4] = true ; kl [5] = true ; kl [6] = true ; kl [7] = false ; kl [8] = true ; kl [9] = true ; kl [10] = true ; kl [11] = true ; kl [12] = true ; kl [13] = true ; kl [14] = true ; kl [15] = false ; kl [16] = true ; kl [17] = true ; kl [18] = true ; kl [19] = true ; kl [20] = true ; kl [21] = true ; kl [22] = true ; kl [23] = false ; kl [24] = true ; kl [25] = true ; kl [26] = true ; kl [27] = true ; kl [28] = true ; kl [29] = true ; kl [30] = true ; kl [31] = false ; kl [32] = true ; kl [33] = true ; kl [34] = true ; kl [35] = true ; kl [36] = true ; kl [37] = true ; kl [38] = true ; kl [39] = false ; kl [40] = true ; kl [41] = true ; kl [42] = true ; kl [43] = true ; kl [44] = true ; kl [45] = true ; kl [46] = true ; kl [47] = false ; kl [48] = true ; kl [49] = true ; kl [50] = true ; kl [51] = true ; kl [52] = true ; kl [53] = true ; kl [54] = true ; kl [55] = false ; kl [56] = true ; kl [57] = true ; kl [58] = true ; kl [59] = true ; kl [60] = true ; kl [61] = true ; kl [62] = true ; kl [63] = false ;

    //  boolean [] [] non_parity = ui.calculating_Key(kl);
    //  ui.print_double_boolean_matrix(non_parity);
    
        
        //cipher_by_DES.print_boolean_matrix(merge_Value);
        //boolean [] exp_Value = cipher_by_DES.expansion(merge_Value);
        
     /*  for ( int index = 0 ; index < 8 ; index++) {
            for ( int index2 = 0 ; index2 < 4 ; index2++ ) {
            for ( int index3 = 0 ; index3 < 16 ; index3++) {
                    System.out.println("sboxs [" + index + "] [" + index2 + "] [" + index3 + "] = convert_to_bits_for_4bayt (  ) ; ");
            }
            }
        }*/
        
        //sboxs= new boolean [8] [4] [16] [4] ;
        //cipher_by_DES.find_ones(exp_Value);
        //cipher_by_DES.print_boolean_matrix(exp_Value);
        //cipher_by_DES.print_boolean_matrix (value);
        //boolean [] [] new_array = cipher_by_DES.divide(value, 8);
       // cipher_by_DES.print_boolean_matrix (new_array[0]);
        //boolean [] character = cipher_by_DES.convert_to_bits ( (int) ( message.charAt (0) ) ) ;
        //cipher_by_DES.print_boolean_matrix(character);
        //cipher_by_DES.print_double_boolean_matrix(new_array);
        
        //boolean [] nw_value_from_exp = cipher_by_DES.expansion(value);
        
/*CRYPT HILL
        Hill cipher_by_Hill ;
        cipher_by_Hill = new Hill(turkce) ;
        int[][] matrix1, matrix2, matrix3;
        int det=1;
        matrix1 = new int[2][2];
        matrix1[0][0]=1;matrix1[0][1]=3;
        matrix1[1][0]=2;matrix1[1][1]=-1;
        matrix2=new int[2][3];
        matrix2[0][0]=2;matrix2[0][1]=0;matrix2[0][2]=-4;
        matrix2[1][0]=5;matrix2[1][1]=-2;matrix2[1][2]=6;
        //cipher_by_Hill.print_Matrix(matrix1);
        //matrix3=cipher_by_Hill.multiply(matrix1,matrix2);
        //matrix3 = cipher_by_Hill.return_det0_matrix(7);
        //cipher_by_Hill.print_Matrix(matrix3);
        //det = cipher_by_Hill.calculate_det(matrix3);
        //det = cipher_by_Hill.professional_calculate_det(matrix3);
        //System.out.println("Det : " + det ) ;
        int [][] donus = {{1,2,3},{4,-2,3},{0,5,-1}};
        int [][] denemematris = {{4,3,15},{-2,5,1},{4,2,9}};
        int [][] denemematris2 = {{1,0,2},{0,5,4},{2,1,3}};
        int [][] denemematris3 = {{1,0,2},{0,3,4},{2,0,4}};
        //cipher_by_Hill.print_Matrix(donus);
        int a = cipher_by_Hill.calculate_det(denemematris3);
        System.out.println(a);
        a = cipher_by_Hill.professional_calculate_det(denemematris3);
        System.out.println("professinal calculate a : " + a ) ;
        //int [][] donus2;
        //donus2 = cipher_by_Hill.divide_matrix(donus, 2);
        //System.out.println("donus2 (bölünmüş matris) uzunluk : " + donus2.length + "donus2 sutun uzunluk : " + donus2[0].length);
        //cipher_by_Hill.print_Matrix(donus2);
        //int [][] donus3 = {{1,2,3,0},{4,-2,5,3},{0,5,-1,2}, {9,8,7,6}};
        //donus3 = cipher_by_Hill.divide_matrix(donus3, 3);
        //System.out.println("donus3 (bölünmüş matris) uzunluk : " + donus3.length + "donus3 sutun uzunluk : " + donus3[0].length);
        //cipher_by_Hill.print_Matrix(donus3);*/
        
        
        
        
        
/*DECRYPT_POLYBIUS
        Polybius cipher_by_polybius2 = new Polybius(english);
        String returnValue, returnValue2 ;
        returnValue = cipher_by_polybius2.crypting("asker is jammers");
        // returnValue= cipher_by_polybius2.decrypting("bilgii güvenliği");
        System.out.println(returnValue);
        returnValue2 = cipher_by_polybius2.decrypting(returnValue);
        System.out.println(returnValue2);*/
        
        
/*DECRYPT_VIGENERE             Vigenere op;
        String check2;
        op = new Vigenere(turkce);
        check2 = op.decrypting("dghj add", "acçe abc" );
        System.out.println(check2);*/
        
        
/*DECRYPT_PicketFence        PicketFence cipher_by_picketFence2 = new PicketFence();
        String[] message=cipher_by_picketFence2.crypting("BİLGİ GÜVENLİĞİ");
        String a = cipher_by_picketFence2.decrypting(message);
        System.out.println(a);*/
        
/*DECRYPT_COLUMNAR  Columnar cipher_by_Columnar2 = new Columnar();
        char[][] cipher_Message;
        cipher_Message = cipher_by_Columnar2.crypting("BİLGİ GÜVENLİĞİ");
        //cipher_by_Columnar2.display_shape_of_data("BİLGİ GÜVENLİĞİ");
        String a = cipher_by_Columnar2.decyrpting(cipher_Message);
           System.out.println(a);*/

        
/*ENTRY TO DES        DES cipher_by_DES;
        cipher_by_DES = new DES();
        cipher_by_DES.char_to_bit('ş');*/


/*CRYPT_COLUMNAR        Columnar cipher_by_Columnar;
        char[][] checkout;
        int s[];
        s = new int[2];
        cipher_by_Columnar = new Columnar ();
        checkout = cipher_by_Columnar.crypting("BİLGİ GÜVENLİĞİ");
        System.out.println(checkout[0]);
        System.out.println(checkout[1]);
        System.out.println(checkout[2]);
        System.out.println(checkout[3]);*/
        
        
/*CRYPT_PICKETFENCE        PicketFence cipher_by_picketFence;
        cipher_by_picketFence = new PicketFence();
        String[] sonuclar;
        sonuclar = new String[2];
        sonuclar = cipher_by_picketFence.crypting("BİLGİ_GÜVENLİĞİ");
        System.out.println( "Sonuçlar : " + sonuclar[0] + "\n " + sonuclar[1] );*/
        
/*CRYPT_VIGENERE        Vigenere op;
        String check;
        op = new Vigenere(turkce);
        check = op.crypting("defg açc", "acçe abc");
        System.out.println(check);*/
        
        
/*CRYPT_POLYBIUS     Polybius cipher_by_poly;
        cipher_by_poly = new Polybius (turkce);
        String ret = cipher_by_poly.crypting("asker is a jammers");
        System.out.println(ret);*/


//DENEME       System.out.println("ç - ğ - ı - ö - ş");
/*DENEME*//* JOptionPane.showMessageDialog(null, "ç - ğ - ı - ö - ş");*/


/*CRYPT_CEASAR, DECRYPT_CEASAR Ceasar Crypt_Ceasar = new Ceasar((short)1, english);
        String yeni = Crypt_Ceasar.crypting("asker");
        System.out.println(yeni);
        Crypt_Ceasar.changeAlphabet("TÜRKÇE");
        String yeni2 = Crypt_Ceasar.crypting("asker");
        System.out.println("yeni2 = " + yeni2);
        String yeni3 = Crypt_Ceasar.decrypting(yeni2, 1);
        System.out.println(yeni3);*/
    }
    
    
}
