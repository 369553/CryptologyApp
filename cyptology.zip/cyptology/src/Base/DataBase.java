
package Base;

public class DataBase {
    private static DataBase Database;
    String[] Alghoritms;
    String[] Themes;
    private DataBase () {
        
    }
    
    public static DataBase getDatabase () {
        if ( Database == null ) {
            Database = new DataBase () ;
        }
        return Database ;
    }
    public String[] getAlghoritms(){
        if ( Alghoritms == null ) {
            Alghoritms = new String[]{
                "CEASAR", "VIGENERE", "COLUMNAR", "POLYBIUS", "HILL", "PICKET FENCE", "DES", "AES"};
            }
        return Alghoritms;
    }
    public String[] getThemes() {
        if ( Themes == null ) {
            Themes = new String[] {
                "Standard", "Alternative", "Blue", "Purple", "Red", "Gold", "Special", "Dark" } ;
        }
        return Themes ;
    }
    
    public String getHints ( String algorithm, boolean isSecond ) {
        switch ( algorithm ) {
            case "CEASAR": return getCeasarText( isSecond ) ;
            case "VIGENERE": return getVigenereText( isSecond ) ;
            case "COLUMNAR": return getColumnarText( isSecond ) ;
            case "POLYBIUS": return getPolybiusText( isSecond ) ;
            case "HILL": return getHillText( isSecond ) ;
            case "PICKET FENCE": return getPicketFenceText( isSecond ) ;
            case "DES": return getDESText( isSecond ) ;
            case "AES": return getAESText( isSecond ) ;
            default: return getCeasarText( isSecond ) ;
        }
    }
    
    private String getCeasarText ( boolean isSecond ) {
        if ( !isSecond )
            return "İsmini Julious Ceasar'dan alan bu şifreleme yönteminde metindeki her bir harf KAYDIRMA MİKTARInca kaydırılarak şifreli metin elde edilir. Kaydırma miktarı alfabenin uzunluğuna bağlıdır. Bilindik alfabeler dışındaki alfabelerle daha güvenli bir şifreleme oluşturulabilir.\nAncak bu şifreleme yöntemi hassas bilgilerin korunması için kullanılamayacak kadar basittir." ;
        return "Sezar şifrelemesinde şifre güvenilirliği alfabenin uzunluğuyla doğru orantılıdır; ancak şifrelenen metnin alfabesi ne kadar uzun olursa olsun çok kısa sürede çözülebilmektedir. Zira sezar şifrelemesi doğrusal olarak her bir durumun denenmesiyle çözülebilen basit bir şifreleme yöntemidir." ;
    }
    private String getColumnarText ( boolean isSecond ) {
        if ( !isSecond )
            return " Basit şifreleme yöntemlerinden olan Sütun(Columnar) şifrelemesi metnin iki boyutlu bir matrise yatay olarak yazılmasıyla uygulanmış olur. Şifreli metin ise dikey olarak okunur. Buradaki matris uzunluğu harflerin sayısına satır ve sütun uzunluğu eşit olacak şekilde ayarlanır. Boş kalan yerlere rastgele harf yerleştirilir." ;
        return " Sütun(Columnar) şifrelemesiyle şifrelenmiş bir metni aldıysan bu metindeki satırlarla sütunları yer değiştirerek ya da metni sütuna dayalı şekilde okuyarak açık metni bulabilirsiniz. Kelimeler arasındaki boşluklar silindiğinden kelimeleri şifreli metni alan kişinin ayırt etmesi gerekmektedir." ;
    }
    private String getVigenereText ( boolean isSecond ) {
        if (!isSecond )
            return "Basit şifreleme yöntemlerinden olan vigenere polialfabetik (çoklu alfabe kullanana) bir şifreleme yöntemidir. Vigenere tablosu istenen alfabenin uzunluğu adedince sezar şifrelemeden oluşturulur. 'A' anahtar harfi ve 'B' açık metin verildiğinde, tablonun 'A' satırının 'B' sütunundaki harf şifreli harf olarak alınır. Bu algoritmada anahtar uzunluğu ve açık metin uzunluğu eşit olmalıdır." ;
        return "Sezar algoritmasında şifreli metin alfabe uzunluğu kadar denemeyle çözülebiliyor. Alfabe uzunluğu kadar sezar algoritması kullanan Vigenere algoritmasının çözülmesi gereken deneme sayısı alfabenin uzunluğunun karesidir." ;
    }
    private String getHillText ( boolean isSecond ) {
        return "HILL" ;
    }
    private String getPicketFenceText ( boolean isSecond ) {
        return "PICKET FENCE" ;
    }
    private String getPolybiusText ( boolean isSecond ) {
        return "POLYBIUS" ;
    }
    private String getAESText ( boolean isSecond ) {
        return "AES" ;
    }
    private String getDESText ( boolean isSecond ) {
        return "DES" ;
    }
    
    
}
