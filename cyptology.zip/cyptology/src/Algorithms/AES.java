package Algorithms;

public class AES {
    private String key ;
    private AES ( String key ) {
        this.key = key ;
    
    }
   /* public String crypting ( String open_Message ) {
        boolean [] [] roundKeys = calculateKeys ( this.key ) ;
        for ( int index = 0 ; index < roundKeys.length ; index++ ) {
            SubstutingBytes () ;
            ShiftingRows () ;
            MixingColumns () ;
        }
        SubstutingBytes () ;
        ShiftingRows () ;
       String a = "ds0";
       return a ;
    }*/
    
    public String decrypting ( String crypt_Message ) {
        StringBuilder open_Message ;
        
        
        
        return new String ("a");
    }
    
    public boolean [] [] calculateKeys ( String key ) {
        boolean [] [] return_Value ;
        if ( key.length() == 8)
        return_Value = new boolean [10] [128] ;
        else if ( key.length() == 12 )
            return_Value = new boolean [12] [128] ;
        else
            return_Value = new boolean [14] [128] ;
        
        /*for ( int index = 0 ; index < return_Value.length ; index++ ) {//DÖNGÜ ANAHTARLARININ HESAPLANMASI
            return_Value [index] = ;
        }*/
        return return_Value ;
    }
    
    
    
    
    public static RSA getAES ( String key ) {
        if ( key.length() == 8 || key.length() == 12 || key.length() == 16 ) {
            return new RSA ( key ) ;
        }
        else
            return null ;
    }
}
