package Algorithms;

public class Polybius {
    Alphabet Alph ;
    Alphabet_of_Polybius alphabet;
    public static Polybius polybius ;
    
    public Polybius (Alphabet alphabet) {
        this.Alph = alphabet ;
        this.alphabet = new Alphabet_of_Polybius( alphabet ) ;
    }
    
    public String crypting ( String open_Message ) {
        StringBuilder message, crypt_Message;
        String new_value;
        message = new StringBuilder ( open_Message );
        crypt_Message = new StringBuilder ();
        for( int index = 0; index < message.length() ; index++ ) {
            char new_character = message.charAt (index);
            if ( new_character == ' ' ) {
                crypt_Message.append (new_character);
            }
            else {
                if (this.alphabet.alphabet.name.equalsIgnoreCase("ENGLISH"))
                    new_value = putting (new_character) ;
                else
                    new_value = putting (new_character) ;
                    crypt_Message.append(new_value);
            }
        }
        return new String (crypt_Message);
    }
    
    public String putting ( char character ) {
        int index = 0, index2 = 0 ;
        String return_value ;
        for ( index = 0 ; index < 5 ; index++ ) {
            for ( index2 = 0; index2 < 5 ; index2++ ) {
                if ( alphabet.matrix[index][index2] == character ) {
                    return_value = String.valueOf(index) + String.valueOf(index2);
                    return return_value;
                }
            }
        }
            for ( int index_s = 0 ; index_s < alphabet.special_state.length ; index_s++ ) {
                if ( character == alphabet.special_state[index_s] ) {
                    return alphabet.special_value[index_s];
                }
            }
        return null;
    }
    
    public String decrypting ( String crypt_Message ) {
        StringBuilder open_Message;
        char special;
        int index=0, index2=0;
        open_Message = new StringBuilder();
        String a;
        String[] characters;
        characters = crypt_Message.split(" ");
//DNM Ayırma doğru        System.out.println(characters[0] + characters[1]);
        for ( index = 0 ; index < characters.length ; index++ ) {
//DNM döngü1 doğru            System.out.println("dongu = " + (index+1));
            for ( index2 = 0 ; index2 < characters[index].length() ; ) {
//DNM döngü2 doğru                System.out.println("dongu2 = " + (index2+1) + "dongu1 = " + (index+1) );
                String character = characters[index].substring(index2,index2+2);
//DNM karakter kodlama doğru                System.out.println((index2+1) + "." + "karakter kodu : " + character);
                open_Message.append( parsing ( character ) );
                special = add_Exception( character );
//DNM add_Exception dan  0 dönmesi ve char a atanması problem değil                System.out.println("special : " + special);
                if ( special != 0 ) {
                    open_Message.append( "{" + special + "}" ) ;
                }
                index2 = index2 + 2 ;
            }
            open_Message.append(" ");
        }
        return new String(open_Message) ;
    }
    
    private char parsing ( String character ) {
//DNM karakter kodu doğru karakter bulma algoritması yanlış        System.out.println ("karakter kodu : " + character + "karakter : " + (this.alphabet.matrix[Integer.parseInt(character.substring(0, 1))][Integer.parseInt(character.substring(0, 1))]));
//DNM karakter kodu bulma doğru        System.out.println("kod ayrıştır : " + character.substring(0, 1) + character.substring(1));
        return this.alphabet
        .matrix[Integer.parseInt(character.substring(0, 1))][Integer.parseInt(character.substring(1))];
    }
    
    private char add_Exception ( String character ) {
        for (int index = 0 ; index < this.alphabet.special_state.length ; index++ ) {
//DNM dongu sayısı doğru System.out.println("add_Exception dongu : " + (index+1));
//DNM special value doğru  if (index == 1 ) System.out.println("add_Exception index=1 special_value[1] : " + this.alphabet.special_value[index]);
            if ( character.equalsIgnoreCase( this.alphabet.special_value[index] ) ) {
                return this.alphabet.special_state[index];
            }
        }
        return 0;
    }

    public static Polybius getPolybius() {
        if ( polybius == null ) {
            polybius = new Polybius( new Alphabet (29, "TÜRKÇE" ) ) ;
        }
        return polybius;
    }
    
    public void changeAlphabet ( String alph ) {
        if ( !this.getAlph().getName().equals( alph ) ){
            if ( alph.equals( "TÜRKÇE" ) )
                setAlph( new Alphabet((short)29, "TÜRKÇE" ) ) ;
            else
                this.alphabet = new Alphabet_of_Polybius( new Alphabet ( (short)26, alph ) ) ;
            this.alphabet = new Alphabet_of_Polybius( this.getAlph() ) ;
        }
        else
            System.out.println( "Alfabe zaten " + alph ) ;
        //free ( this.alphabet ) ; C'deki bu fonksiyonun java daki karşılığını bul
    }
    
    public Alphabet getAlph() {
        if ( Alph == null ) {
            Alph = new Alphabet((short) 29, "TÜRKÇE" ) ;
        }
        return Alph ;
    }
    
    public void setAlph ( Alphabet Alph ) {
        this.Alph = Alph ;
    }
    
    class Alphabet_of_Polybius{
        Alphabet alphabet;
        char[] special_state;
        String[] special_value;
        char[][] matrix;
        public Alphabet_of_Polybius (Alphabet alphabet) {
            this.alphabet = alphabet ;
            matrix = new char [5] [5];
            fill_PolyAlphabet();
        }
        
        private void fill_PolyAlphabet(){
            if ( this.alphabet.name.equalsIgnoreCase("ENGLISH") ) {
                matrix[0][0] = 97; matrix[0][1] = 98; matrix[0][2] = 99; matrix[0][3] = 100; matrix[0][4] = 101; matrix[1][0] = 102; matrix[1][1] = 103; matrix[1][2] = 104; matrix[1][3] = 105; matrix[1][4] = 107; matrix[2][0] = 108; matrix[2][1] = 109; matrix[2][2] = 110; matrix[2][3] = 111; matrix[2][4] = 112; matrix[3][0] = 113; matrix[3][1] = 114; matrix[3][2] = 115; matrix[3][3] = 116; matrix[3][4] = 117; matrix[4][0] = 118; matrix[4][1] = 119; matrix[4][2] = 120; matrix[4][3] = 121; matrix[4][4] = 122;
                special_state = new char [1];
                special_value = new String [1];
                special_state[0] = 'j';
                special_value[0] = "13" ;
            }
            else {
                matrix[0][0] = 97; matrix[0][1] = 98; matrix[0][2] = 99; matrix[0][3] = 100; matrix[0][4] = 101; matrix[1][0] = 102; matrix[1][1] = 103; matrix[1][2] = 287; matrix[1][3] = 104; matrix[1][4] = 105; matrix[2][0] = 106; matrix[2][1] = 107; matrix[2][2] = 108; matrix[2][3] = 109; matrix[2][4] = 110; matrix[3][0] = 111; matrix[3][1] = 112; matrix[3][2] = 114; matrix[3][3] = 115; matrix[3][4] = 351; matrix[4][0] = 116; matrix[4][1] = 117; matrix[4][2] = 118; matrix[4][3] = 121; matrix[4][4] = 122;
                special_state = new char [4];
                special_value = new String[4];
                special_state[0] = 'ç'; special_state[1] = 'ı'; special_state[2] = 'ö'; special_state[3] = 'ü';
                special_value[0] = "02"; special_value[1] = "14"; special_value[2] = "30"; special_value[3] = "41";
            }
        }
    }
}



/*
 public String crypting ( String message ) {
        String new_value;
        this.message = new StringBuilder ( message );
        this.crypt_Message = new StringBuilder ();
        crypt_Message.setLength(this.message.length()*2);
        for(int index = 0; index<message.length();index++){
            char new_character = message.charAt(index);
            if ( new_character == ' '){
                index = index*2;
                crypt_Message.setCharAt(index, new_character);
                index = index/2;
            }
            else {
                if (this.alphabet.name.equalsIgnoreCase("ENGLISH"))
                    new_value = putting_ENG (new_character) ;
                else
                   new_value = putting_TR (new_character);
                index=index*2;
                crypt_Message.setCharAt(index, new_value.charAt(0));
                crypt_Message.setCharAt(index+1, new_value.charAt(1));
                index=index/2;
            }
        }
        return new String (crypt_Message);
    }
}*/




/*public String putting_ENG ( char character ) {
        int index, index2;
        String return_value;
        for ( index = 0 ; index < 5 ; index++ ) {
            for ( index2 = 0 ; index2 < 5 ; index2++ ) {
                if ( index == 1 ) {
                    if (index2 == 3) {
                        if ( character == alphabet.special_state[0] ) {
                            System.out.println("special_state = " + alphabet.special_state[0]);
                            return_value = String.valueOf(index) + String.valueOf(index2) ;
                            return return_value;
                        }
                    }
                }
                
                if ( alphabet.matrix[index][index2] == character ) {
                    return_value = String.valueOf(index) + String.valueOf(index2) ;
                    return return_value;
                }
            }
        }
           return null;
    }
    public String putting_TR ( char character ) {
        int index=0, index2=0;
        String return_value;
        for ( index = 0 ; index < 5 ; index++ ) {
            for ( index2 = 0; index2 < 5 ; index2++ ) {
                if ( poly[index][index2] == character ) {
                    return_value = String.valueOf(index) + String.valueOf(index2);
                    return return_value;
                }
            }
        }
            for ( int index_s = 0 ; index_s < special_state.length ; index_s++ ) {
                if ( character == special_state[index_s] ) {
                    switch ( index_s ) {
                        case 0:{
                            return_value = "02";
                            return return_value;
                        }
                        case 1:{
                            return_value = "14";
                            return return_value;
                        }
                        case 2:{
                            return_value = "30";
                            return return_value;
                        }
                        case 3:{
                            return_value = "42";
                            return return_value;
                        }
                    }
                }
            }
        return null;
    }*/

/*

    
    public String decrypting ( String crypt_Message ) {
        StringBuilder open_Message;
        int count=0, index=0, index2=0;
        open_Message = new StringBuilder();
        String a;
        String[] characters;
        characters = crypt_Message.split(" ");
        for ( index = 0 ; index < characters.length ; index++ ) {
            count=0;index2=0;
            for ( count=0 ; count < characters[index].length() / 2 ; count++) {
                a = characters[index].substring(index2, index2+2) ;
                System.out.println(a);
                open_Message.append(char_Finder_TR(characters[index].substring(index2, index2+2)));
                index2 = index2 + 2 ;
                System.out.println(open_Message);
            }
            open_Message.append(" ");
        }
        return new String(open_Message) ;
    }
    
    private String char_Finder_TR ( String value ) {
        switch (value){
            case "00" : return "a";
            case "01" : return "b";
            case "02" : return "c{ç}";
            case "03" : return "d";
            case "04" : return "e";
            case "10" : return "f";
            case "11" : return "g";
            case "12" : return "ğ";
            case "13" : return "h";
            case "14" : return "ı{i}";
            case "20" : return "j";
            case "21" : return "k";
            case "22" : return "l";
            case "23" : return "m";
            case "24" : return "n";
            case "30" : return "o{ö}";
            case "31" : return "p";
            case "32" : return "r";
            case "33" : return "s";
            case "34" : return "ş";
            case "40" : return "t";
            case "41" : return "u{ü}";
            case "42" : return "v";
            case "43" : return "y";
            case "44" : return "z";
        }
        return null;
    }
    
*/