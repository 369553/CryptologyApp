package Algorithms;

public class Ceasar {
    Alphabet alphabet;
    short num_shift;
    static boolean isReport = false, isCrypt = true ;
    public static Ceasar ceasar ;
    String reportText ;
    
    public Ceasar (short num_shift, Alphabet alphabet) {
        this.num_shift = num_shift;
        this.alphabet = alphabet;
    }
    
    public Ceasar ( Alphabet alphabet ) {
        this.alphabet = alphabet;
        this.num_shift = 0;
    }
    
    public String crypting (String open_Message) {
        StringBuilder message, crypt_Message, report ;
        report = new StringBuilder() ;
        message = new StringBuilder (open_Message);
        crypt_Message = new StringBuilder (open_Message);
        if ( isReport == true && isCrypt == true )
            report.append( "-----\nŞİFRELEME RAPORLAMASI\nALGORİTMA: CEASAR\nAÇIK METİN: " + open_Message + "\nAlfabe: " + getAlphabet().getName() + "\n\n********\n\n" ) ;
        for( int index = 0; index < message.length() ; index++ ){
            char new_character = message.charAt(index);
            if ( new_character == ' ')
                crypt_Message.setCharAt(index, new_character);
            else {
                new_character = shifting (new_character);
                crypt_Message.setCharAt(index, new_character);
                if ( isReport == true ){
                    report.append( index + ". karakter: " + message.charAt( index ) + " >> " + new_character + "\n" ) ;
                }
            }
        }
        if ( isReport == true && isCrypt == true ) {
            report.append( "\n********\n\nŞİFRELİ METİN: " + crypt_Message + "\n\nRapor Sonu." ) ;
            reportText = new String ( report ) ;
        }
        return new String (crypt_Message);
    }
    
    protected char shifting (char character){
        char shift_character;
        for (int index = 0 ; ;index++ ){
            if (character == alphabet.letters[index]){
                shift_character = alphabet.letters[(index + this.num_shift)%alphabet.letters.length] ;
                return  shift_character;
            }
        }
    }
    
    public void changeAlphabet (String name_of_alphabet){
        if (name_of_alphabet.equalsIgnoreCase("TÜRKÇE")){
            if (this.alphabet.name.equalsIgnoreCase("TÜRKÇE")){
                System.out.println("Alfabe zaten Türkçe!");
            }
            else{
                alphabet = new Alphabet((short) 29, "TÜRKÇE");
            }
        }
        if (name_of_alphabet.equalsIgnoreCase("ENGLISH")){
            if (this.alphabet.name.equalsIgnoreCase("ENGLISH")){
                System.out.println("Alfabe zaten İngilizce!");
            }
            else{
                alphabet = new Alphabet((short) 26, "ENGLISH");
            }
        }
    }
    
    public boolean changeNumberofShift(short num_shift){
        this.num_shift = (short) ( num_shift % (this.alphabet.letters.length) );
        return true;
    }
    
    public String decrypting (String message, int shift_no) {
        short shift_number = (short) - ((shift_no) % (this.alphabet.letters.length));
        changeNumberofShift(shift_number);
        isCrypt = false ;
        return crypting(message);
    }

    public Alphabet getAlphabet() {
        return alphabet;
    }

    public void setAlphabet(Alphabet alphabet) {
        this.alphabet = alphabet;
    }

    public short getNum_shift() {
        return num_shift;
    }

    public void setNum_shift(short num_shift) {
        this.num_shift = num_shift;
    }
    
    public static Ceasar getCeasar () {
        if ( ceasar == null ) {
            ceasar = new Ceasar( (short)1, new Alphabet( 29, "TÜRKÇE" ) ) ;
        }
        return ceasar ;
    }
    
    public void setIsReport ( boolean value ) {
        isReport = value ;
    }
    
    public String getReportText ( ) {
        if ( reportText != null ) {
            return reportText ;
        }
        else
            return "Raporlama özelliği aktif edilmemiş" ;
}


}