package Algorithms;

import java.util.Random;
import java.math.*;

public class Hill {
    Alphabet alphabet;
    
    public Hill ( Alphabet alphabet ) {
        this.alphabet = alphabet ;
    }
    
    
   public int[][] crypting (String open_Message) {
        StringBuilder message = new StringBuilder (open_Message);
        int [][] crypt_Message;
        int [][] matrix_Message;
        int [][] matrix_det0;
        if ( open_Message.length()%3 == 0 ){//3 değeri bir bağımlılık ifade ediyor,
            matrix_Message = new int[3][open_Message.length()/3];
        }
        else{
            matrix_Message = new int[3][(open_Message.length()/3)+1];
        }
        matrix_det0 = return_det0_matrix(matrix_Message.length);
        if ( matrix_det0.length != matrix_Message.length ){
            System.out.println("Şifreleme hatası: mesaj uzunluğu - det matris uzunluğu uyumsuzluğu");
            return null;
        }
        crypt_Message = new int[matrix_Message.length][matrix_Message[0].length];
        matrix_Message = fill (open_Message) ;
        crypt_Message = multiply ( matrix_Message, matrix_det0 ) ;
        return crypt_Message;
   }
   
   
   public int[][] return_det0_matrix ( int length ) { //Determinantı 1 ya da -1 olan matris döndüren bir fonk yaz
       int index = 0 , index2 = 0 , random_det_line=0, random_copy_line_no=0, random_coefficient=0 ;//Randomline, randomcopyline, random coefficient
       boolean special_state = false , special_state2 = false ;
       int[] [] matrix ;
       Random r = new Random();
       matrix = new int [length] [length] ;
       random_det_line = r.nextInt(length);
       System.out.println ( "secilen satır : " + random_det_line);
       for (index = 0 ; index < length ; index++ ) {
           if ( index == random_det_line ) {
               do{
                   random_copy_line_no = r.nextInt(length);
               }
               while (random_det_line==random_copy_line_no);
               random_coefficient = r.nextInt(1000);
               System.out.println("copy line : " + random_copy_line_no);
               System.out.println("coeffienct : " + random_coefficient);
               special_state = true;
           }
           for ( index2 = 0 ; index2 < length ; index2++ ) {
               if ( special_state == false )
                    matrix[index][index2] = r.nextInt(1000);
               else if (random_det_line > random_copy_line_no)
                   matrix[index][index2] = ( matrix[random_copy_line_no][index2] * random_coefficient);
               else
                   special_state2 = true;
           }
           special_state = false ;
           if ( special_state2 == true && index == random_copy_line_no ) {
               for (int count = 0 ; count < length ; count++ ) {
                   matrix[random_det_line][count] = ( matrix[random_copy_line_no][count] * random_coefficient);
               }
               special_state2 = false ;
           }
       }
       return matrix ;
   }
   
   private int[][] fill ( String message ) { // fill () fonk.unun tersi yazılmalı
       int index, index2, col, step = 0 ;
       int [][] number_message;
       if ( message.length() % 3 == 0 ) // buradaki 3 değeri de aynı bağımlılığı ifade ediyor.
           col = message.length() / 3 ;
       else
           col = ( message.length() / 3 ) + 1 ;
       number_message = new int [3][col];
       for ( index = 0 ; index < 3 ; index++ ) {
           for ( index2 = 0 ; index2 < col ; index2++ ) {
               if(message.charAt(step) == ' ')
                   number_message[index][index2] = 0;
               else
                   number_message[index][index2] = find_in_alphabet(message.charAt(step));
               if ( number_message [index][index2] == -1 ){
                   System.out.println ( "Şifreleme esnasında hata oluştu. Lütfen girdiğiniz metnin alfabeye uygunluğunu kontrol ediniz." ) ;
                   break;
               }
               step++;
           }
       }
       return number_message;
   }
   
   
   private int find_in_alphabet ( char character ) {
        for ( int index = 0 ; index < this.alphabet.letters.length ; index++ ) {
            if ( character == this.alphabet.letters[index] )
                return index;
        }
        return -1 ;
   }
   
   public int [][] multiply ( int [][] first_matrix, int [][] det0_matrix ) {
       int index = 0 , index2 = 0 , index3 = 0 , temp=0;
       int [][] multiply_matrix ;
       multiply_matrix = new int[det0_matrix.length][det0_matrix[0].length]; //Çok önemli not; Burada bu kod yerine multiply_matrix=det0_matrix dendiğinde multiply_matrix'in değeri değişince det0_matrix'in de değeri değişiyor..!
       if(first_matrix[0].length != det0_matrix.length)
           System.out.println("A'nın kolon sayısı B'nin satır sayısına eşit olmadığından bu çarpım tanımlı değildir");
       else{
           for ( index = 0 ; index < first_matrix.length ; index++ ) {
               //System.out.println("det0_matrix[0][2] ? " + det0_matrix[0][2]);
               for ( index2 = 0 ; index2 < det0_matrix[0].length ; index2++ ) {
                   temp=0;
                   for ( index3 = 0 ; index3 < first_matrix.length ; index3++ ) {
                       //System.out.println("det0_matrix[" + index3 + "][" + index2 + "] = " + det0_matrix[index3][index2] ) ;
                       temp = temp + ( first_matrix[index][index3] * det0_matrix[index3][index2] );
                       //System.out.println( "temp = " + temp + " + (first_matrix[" + index + "][" + index3 + "] (" + first_matrix[index][index3] + ") * det0_matrix[" + index3 + "][" + index2 + "] " + det0_matrix[index3][index2] + ") , temp = " + temp) ;
                   }
                   multiply_matrix[index][index2] = temp ;
                   //System.out.println("multiply_matrix[" + index + "][" + index2 + "] = " + multiply_matrix[index][index2] ) ;
                  temp=0;
                   //System.out.println( "matris[" + index + "][" + index2 + "(temp) = " + temp ) ;
               }
           }     
       }
       return multiply_matrix;
   }
   
   public int calculate_det ( int [] [] matrix) {
       int return_value=0;
       if ( matrix.length != matrix[0].length ){
           System.out.println ( "Hatalı parametreden dolaylı determinant hesaplanmıyor" ) ;
           return -1;
       }
        if ( matrix.length == 2 ) {
            return_value = ( ( matrix[0][0] * matrix[1][1] ) - ( matrix[1][0] * matrix[0][1] ) );
            return return_value;
        }
        /*if ( matrix.length == 3 ) {
            return_value = (matrix[0][0] * ( calculate_det(new int[][]{{matrix[1][1],matrix[1][2]},{matrix[2][1],matrix[2][2]}}) ) * 
            matrix[0][1] * ( calculate_det(new int[][]{{matrix[1][0],matrix[1][2]},{matrix[2][0],matrix[2][2]}}) ) *
            matrix[0][2] * ( calculate_det( new int[] [] { { matrix[1][0] , matrix[1][1]} , {matrix[2][0] , matrix[2][1] } } ) ) ) ;
        }*/
        if ( matrix.length == 3 ) {
            int[][] a1,a2,a3;
            a1 = new int[2][2];
            a2 = new int[2][2];
            a3 = new int[2][2];
            int [][] donus = {{matrix[1][1],matrix[1][2]},{matrix[2][1],matrix[2][2]}};
            int dondeger=calculate_det(donus);
            //System.out.println(dondeger);
            int [][] donus2 = {{matrix[1][0],matrix[1][2]},{matrix[2][0],matrix[2][2]}};
            
            int dondeger2=calculate_det(donus2);
            //System.out.println(dondeger2);
            int [][] donus3 = { { matrix[1][0] , matrix[1][1]} , {matrix[2][0] , matrix[2][1] } };
            
            int dondeger3=calculate_det(donus3);
            //System.out.println(dondeger3);
            
            return_value = ( (matrix[0][0] * ( calculate_det(new int[][]{{matrix[1][1],matrix[1][2]},{matrix[2][1],matrix[2][2]}}) ) ) - 
            (matrix[0][1] * ( calculate_det(new int[][]{{matrix[1][0],matrix[1][2]},{matrix[2][0],matrix[2][2]}}) ) ) +
            (matrix[0][2] * ( calculate_det( new int[] [] { { matrix[1][0] , matrix[1][1]} , {matrix[2][0] , matrix[2][1] } } ) ) ) ) ;
            //System.out.println(return_value);
        }
        
       /*
       return_value = ( (matrix[0][0])*((matrix[1][1]*matrix[2][2])-(matrix[2][1]-matrix[1][2])) +
               (matrix[0][1])*((matrix[1][0]*matrix[2][2])-(matrix[2][0]-matrix[1][2])) +  
               (matrix[0][2])*((matrix[1][0]*matrix[2][1])-(matrix[2][0]-matrix[1][1])) ) ;
        */
       return return_value;
   }
   
   public void print_Matrix( int[][] matrix){
       int index = 0 , index2 = 0 ;
       for ( index = 0 ; index < matrix.length ; index++ ) {
           for ( index2 = 0 ; index2 < matrix[0].length ; index2++ ) {
               System.out.println("matris[" + index + "][" + index2 + "] = " + matrix[index][index2] ) ;
           }
       }
   }
   
   public int professional_calculate_det ( int [] [] matrix ) { // Recursive olarak determinant hesabı
       int index = 0 , index2 = 0 , index3 = 0 , length = matrix.length , value=0;
       if ( length == 2 ) {
           return ( ( matrix[0][0] * matrix[1][1] ) - ( matrix[1][0] * matrix[0][1] ) ) ; 
       }
       else {
            for ( index = 0 ; index < length ; index++ ) {
                value += (
                    ( (int) Math.pow (-1 , ( 1 + ( index + 1 ) ) ) ) * (matrix[0][index]) * ( professional_calculate_det ( divide_matrix ( matrix , index ) ) ) ) ;
            }
       }
       return value;
   }
   
   public int [] [] divide_matrix ( int [] [] main_matrix , int referance ) { // minörü hesaplıyor
       int [] [] matrix;
       int index = 0 , index2 = 0, length = ( main_matrix.length -1 ) , current = 0 , current2 = 0 ;
       matrix = new int [length] [length] ;
       for ( index = 0 ; index < length ; index++ ) {
            current = index + 1 ;
            current2 = 0 ;
           for ( index2 = 0 ; index2 < length ; index2++ ) {
               if ( referance == index2 )
                   current2 = index2 + 1 ;
               matrix [index] [index2] = main_matrix [current] [current2] ;
               current2++ ;
           }
       }
       return matrix;
   }
   
    public String decrypting( int [] [] crypt_Message, int [] [] key ) { //transpoz fonk. ,...
       StringBuilder open_Message= new StringBuilder("w") ;
       int [] [] reverse_Key ;
       int [] [] open_Matrix ;
       open_Matrix = new int [crypt_Message.length] [crypt_Message[0].length] ;
       //reverse_Key = reversing ( key ) ;
         //ADIM 1 : anahtarın tersini bul
         //ADIM 2 : anahtarın tersiyle şifreli mesajı çarp open_Matrix = multiply( key , cyrpt_Message ) ; 
         //ADIM 3 : Elde edilen matrisi alfabeye göre ayır (fill() fonk.unun yaptığı işlemin tersi )
           
           
        return new String (open_Message);
    }
    
   /* public int [] [] reversing ( int [] [] matrix ) { //MATRİSİN SATIR VE SÜTUNLARININ UZUNLUĞUNUN EŞİT OLMASI KONTROLĞ EKLE
        int [] [] reverse_Matrix ;
        int length = matrix.length ;
        reverse_Matrix = new int [matrix.length][matrix.length] ;
        double coefficient =  ( 1/ ( (double) professional_calculate_det ( matrix ) ) );
        int [] [] cofactors ;
        cofactors = cofactoring ( matrix ) ;
        trans_cofactors = transpozing ( matrix ) ;
        for ( int index = 0 ; index < matrix.length ; index++ ) {
            for (int index2 = 0 ; index2 < matrix.length ; index2+++ ) {
                reverse_Matrix [index] [index2] = trans_cofactors [index] [index2] * coefficient ;
            }
        }
        return reverse_Matrix ;
    }*/
    
    
    public int [] [] transpozing ( int [] [] matrix ) {
        return new int[2][2];
    }
   
   
}