package Control;

import Algorithms.Ceasar;
import Algorithms.Columnar;
import Algorithms.Vigenere;
import Base.SystemSettings;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ReportSystem {
    private static ReportSystem ReportManager ;
    private static File savefile ;
    
    private ReportSystem( String path ) {
        path = path + "/ProgramReport.txt" ;
        savefile = new File( path ) ;
        if ( savefile == null ) {
            getReportManager() ;
        }
            try {
                savefile.createNewFile() ;
            }
            catch( IOException e ){
                e.printStackTrace() ;
                System.err.println( "Rapor dosyası oluşturulamadı!" ) ;
            }
        System.out.println( path ) ;
    }

    public static ReportSystem getReportManager() {
        if ( ReportManager == null ) {
            ReportManager = new ReportSystem( SystemSettings.getSettings().getPATHPosition() ) ;
        }
        return ReportManager;
    }

    public static void setReportManager(ReportSystem ReportManager) {
        ReportSystem.ReportManager = ReportManager;
    }
    
    public boolean Reporting ( String algorithm ) {
        if ( !savefile.exists() ) {
            try{
            savefile.createNewFile() ;
            }
            catch ( IOException e ) {
                e.printStackTrace();
            }
        }
        if ( !savefile.canWrite() ) {
            System.out.println( "Dosya okuma izni yok" ) ;
            return false ;
        }
        if ( !savefile.isFile() ){
            System.out.println("HATA : Dosya oluşturulmamış");
            return false ;
        }
        switch ( algorithm ) {
            case "CEASAR": { Ceasar.getCeasar().setIsReport( true ) ; break ; }
            case "COLUMNAR": { Columnar.getColumnar().setIsReport( true ) ; break ; }
            case "VIGENERE": { Vigenere.getVigenere().setIsReport( true ) ; break ; }
           /* case "CEASAR": { Ceasar.getCeasar().setIsReport( true ) ; break ; }
            case "CEASAR": { Ceasar.getCeasar().setIsReport( true ) ; break ; }
            case "CEASAR": { Ceasar.getCeasar().setIsReport( true ) ; break ; }
            case "CEASAR": { Ceasar.getCeasar().setIsReport( true ) ; break ; }
            case "CEASAR": { Ceasar.getCeasar().setIsReport( true ) ; break ; }*/
            
            
            
            
        }
        return true ;
    }
    
    public boolean Saving ( String algorithm ) throws IOException {
        String writeInf = new String() ;
        switch ( algorithm ) {
            case "CEASAR": { writeInf = Ceasar.getCeasar().getReportText() ; break ; }
            case "COLUMNAR": { writeInf = Columnar.getColumnar().getReportText() ; break ; }
            case "VIGENERE": { writeInf = Vigenere.getVigenere().getReportText() ; break ; }
          /*  case "CEASAR": { writeInf = Ceasar.getCeasar().getReportText() ; break ; }
            case "CEASAR": { writeInf = Ceasar.getCeasar().getReportText() ; break ; }
            case "CEASAR": { writeInf = Ceasar.getCeasar().getReportText() ; break ; }
            case "CEASAR": { writeInf = Ceasar.getCeasar().getReportText() ; break ; }
            case "CEASAR": { writeInf = Ceasar.getCeasar().getReportText() ; break ; }*/
        }
        return write(writeInf) ;
       /* System.err.println( writeInf ) ;
        return true; //GEÇİCİ*/
    }
    
    public boolean write ( String text ) throws IOException {
        //PrintWriter writer = new PrintWriter ( new FileWriter ( savefile.getAbsoluteFile() ) ) ;
        // FileWriter writer = new FileWriter( savefile.getAbsoluteFile() ) ;
        BufferedWriter writer = new BufferedWriter( new FileWriter( savefile.getAbsoluteFile() ) ) ;
        long space = savefile.getTotalSpace() ;
        System.out.println( text );
        writer.write(text);//charset ayarlanıp, kayıt biçimi değiştirilebilir. kayıt biçimi değiştirilmeyecekse bile charset değiştirilmeli.
        writer.flush() ;
        writer.close();
        if ( savefile.getTotalSpace() < space )
            return true ;
        else 
            return false ;
        
    }
    
    
}