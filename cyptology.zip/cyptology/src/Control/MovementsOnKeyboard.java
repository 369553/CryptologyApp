package Control;

import Algorithms.Alphabet;
import Algorithms.Ceasar;
import Algorithms.Polybius;
import Algorithms.Vigenere;
import Views.CryptScreen;
import Views.ReqVigenere;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MovementsOnKeyboard implements KeyListener{
    CryptScreen screen;
    ReqVigenere screenSecond ;
    char character ;
    String currAlg ;
    public MovementsOnKeyboard (CryptScreen screen) {
        this.screen = screen;
    }
    
    public MovementsOnKeyboard ( ReqVigenere screenSecond ) {
        this.screenSecond = screenSecond ;
    }
    /* Sezar şifrelemesi için ve polybius şifrelemesi için abcçde.. den başka harf girilmemeli, 
bu harflerin küçüğü girilse bile büyük hale çevrilmeli */
    
    /* Burada alfabe bilgisi tutulmalı. Yani Türkçe afabesi seçiliyse x, w girilmemeli
    İngilizce seçiliyse ç,ğ,ü,ı,... girilmemeli.*/

    @Override
    public void keyTyped(KeyEvent e) {
       if ( screen != null ) {
            if ( e.getSource() == screen.getOpen_Text() ) {
                currAlg = new String ( screen.getSelect_Algh().getSelectedItem().toString() ) ;
                if ( currAlg.equals( "CEASAR" ) || currAlg.equals( "VIGENERE" ) ) {
                        character = e.getKeyChar() ;
                        if ( currAlg.equals( "CEASAR" ) ) {
                            if ( check (character, Ceasar.getCeasar().getAlphabet() ) != true ) {
                                e.consume() ;
                            }
                        }
                        else {
                            if ( check (character, Vigenere.getVigenere().getAlphabet() ) != true ) {
                                e.consume() ;
                            }
                        }
                }
                if ( currAlg.equals( "POLYBIUS" ) ) {
                    character = e.getKeyChar() ;
                    if ( check(character, Polybius.getPolybius().getAlph() ) != true )
                        e.consume() ;
                }
                    // Burada seçili algoritmaların seçili gereksinimlerine göre karakter kontrolleri yapılmalı
            }
        }
       if ( screenSecond != null ) {
           if ( e. getSource() == screenSecond.getTextField1st() ) {
               int length = screenSecond.getTextField1st().getText().length() ;
               character = e.getKeyChar() ;
                if ( check (character, Vigenere.getVigenere().getAlphabet() ) != true ) {
                    e.consume() ;
                }
               if ( Vigenere.getVigenere().getLengthofKey() <= length )
                   e.consume() ;
           }
       }
        //TUŞ BASILDIĞINDA
    }

    @Override
    public void keyPressed(KeyEvent e) {
    //TUŞ 
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if ( screen != null ) {
            if ( e.getSource() == screen.getOpen_Text() && screen.getCurrent_algorithm().equals( "VIGENERE" ) )
            Vigenere.getVigenere().setLengthofKey(screen.getOpen_Text().getText().length());
        }
    //TUŞ BIRAKILDIĞINDA
    }
    
    public boolean check ( char character, Alphabet alphabet ) {
        for ( int i = 0 ; i < alphabet.getLength() ; i++ ) {
            if ( character == alphabet.getLetters()[i] ) {
                return true;
            }
        }
        return false ;
    }
    
}
