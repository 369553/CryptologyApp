package Control;

import Algorithms.Ceasar;
import Views.ReqCeasar;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ChangeListen implements ChangeListener {
    ReqCeasar rc ;
    int value ;
    public ChangeListen ( ReqCeasar rc ) {
        this.rc = rc ;
        
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        value = ( (JSlider) e.getSource() ).getValue() ;
        Ceasar.getCeasar().setNum_shift( (short) value ) ;
        rc.NameandRenameLabel_1st() ;
    }
}
