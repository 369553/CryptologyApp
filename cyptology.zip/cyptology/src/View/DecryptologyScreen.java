package View;

import javax.swing.JPanel;

public class DecryptologyScreen extends JPanel {
    
}
