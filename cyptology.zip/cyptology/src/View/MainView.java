package View;

import Control.Actions;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainView {
    JFrame frame;
    JPanel firstscreen;
    JButton firstbutton, secondbutton, thirdbutton;
    Actions action;
    CryptologyScreen secondscreen;
    DecryptologyScreen thirdscreen;
    DevDecryptologyScreen fourthscreen;
    public MainView () {
        getFrame().add(getFirstscreen());
/*NOTE*/        //getFrame().setContentPane(getFirstscreen()); // Bu kod yerine getframe.add yapılırsa actions da bu panel kaldırılabiliyor, dolayısıyla program kullanılmayan nesneleri bellekte tutmamuş oluyır.
        getFrame().setVisible(true);
        getFrame().setResizable(false);
    }

    public JFrame getFrame() {
        if (frame == null){
            frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setBounds(400, 140, 615, 500);
            frame.setBackground(Color.yellow);
        }
        return frame;
    }

    public void setFrame(JFrame frame) {
        this.frame = frame;
    }

    public JPanel getFirstscreen() {
        if ( firstscreen == null ) {
            firstscreen = new JPanel();
            firstscreen.setBounds(0, 0,  615, 500);
            firstscreen.setLayout(null);
            firstscreen.add(getFirstbutton());
            firstscreen.add(getSecondbutton());
            firstscreen.add(getThirdbutton());
        }
        return firstscreen;
    }

    public void setFirstscreen(JPanel firstscreen) {
        this.firstscreen = firstscreen;
    }

    public JButton getFirstbutton() {
        if ( firstbutton == null ) {
            firstbutton = new JButton("ŞİFRELE");
            firstbutton.setBounds(247, 140, 120, 40);
            firstbutton.addActionListener(getAction());
        }
        return firstbutton;
    }

    public void setFirstbutton(JButton firstbutton) {
        this.firstbutton = firstbutton;
    }

    public Actions getAction() {
        if ( action == null ) {
       //     action = new Actions(this);
        }
        return action;
    }

    public void setAction(Actions action) {
        this.action = action;
    }

    public JButton getSecondbutton() {
        if ( secondbutton == null ){
            secondbutton = new JButton("ŞİFRE ÇÖZ");
            secondbutton.setBounds(247, 195, 120, 40);
            secondbutton.addActionListener(getAction());
        }
        return secondbutton;
    }

    public void setSecondbutton(JButton secondbutton) {
        this.secondbutton = secondbutton;
    }

    public JButton getThirdbutton() {
        if ( thirdbutton == null ) {
            thirdbutton = new JButton("GELİŞMİŞ ŞİFRE ÇÖZ");
            thirdbutton.setBounds(247, 250, 120, 40);
            thirdbutton.addActionListener (getAction());
        }
        return thirdbutton;
    }

    public void setThirdbutton(JButton thirdbutton) {
        this.thirdbutton = thirdbutton;
    }

    public CryptologyScreen getSecondscreen() {
        if ( secondscreen == null ) {
            secondscreen = new CryptologyScreen();
        }
        return secondscreen;
    }

    public void setSecondscreen(CryptologyScreen secondscreen) {
        this.secondscreen = secondscreen;
    }

    public DecryptologyScreen getThirdscreen() {
        if ( thirdscreen == null ) {
            thirdscreen = new DecryptologyScreen();
            thirdscreen.setBounds(0, 0,  615, 500);
            thirdscreen.setLayout(null);
        }
        return thirdscreen;
    }

    public void setThirdscreen(DecryptologyScreen thirdscreen) {
        this.thirdscreen = thirdscreen;
    }

    public DevDecryptologyScreen getFourthscreen() {
        if ( fourthscreen == null ) {
            fourthscreen = new DevDecryptologyScreen();
            fourthscreen.setBounds(0, 0,  615, 500);
            fourthscreen.setLayout(null);
        }
        return fourthscreen;
    }

    public void setFourthscreen(DevDecryptologyScreen fourthscreen) {
        this.fourthscreen = fourthscreen;
    }
    
}
