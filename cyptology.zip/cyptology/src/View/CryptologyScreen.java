package View;

import Algorithms.Alphabet;
import Control.Actions;
import Control.MovementsOnKeyboard;
import java.util.Hashtable;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

public class  CryptologyScreen extends JPanel {
    
    JComboBox algorithms;
    JTextField text;
    String[] names_of_algorithms;
    JButton complete;
    MovementsOnKeyboard mov_key;
    JPanel req_panel;
    Actions action;
    
    public CryptologyScreen () {
        this.setBounds(0, 0,  615, 500);
        this.setLayout(null);
        this.getText();
        this.getNames_of_algorithms();
        this.getAlgorithms();
        this.getComplete();
    }

    public JTextField getText() {
        if ( text == null ) {
            text = new JTextField ();
            text.setBounds(132, 210, 200, 40);
            text.addKeyListener(getMov_key());
            text.setToolTipText("AÇIK METİN");
            this.add(text);
        }
        return text;
    }

    public void setText(JTextField text) {
        this.text = text;
    }
    
    public JComboBox getAlgorithms() {
        if ( algorithms == null ){
            algorithms = new JComboBox(getNames_of_algorithms());
            algorithms.addActionListener(getAction());
            algorithms.setBounds(382, 220, 100, 20);
            this.add(algorithms);
        }
        return algorithms;
    }

    public void setAlgorithms(JComboBox algorithms) {
        this.algorithms = algorithms;
    }

    public String[] getNames_of_algorithms() {
        if ( names_of_algorithms == null ){
            names_of_algorithms = new String[9];
            names_of_algorithms[0] = ""; names_of_algorithms[1] = "CEASAR"; names_of_algorithms[2] = "VIGENERE"; names_of_algorithms[3] = "POLYBIUS"; names_of_algorithms[4] = "HILL"; names_of_algorithms[5] = "COLUMNAR"; names_of_algorithms[6] = "PICKET FENCE"; names_of_algorithms[7] = "DES"; names_of_algorithms[8] = "AES";
        }
        return names_of_algorithms;
    }

    public void setNames_of_algorithms(String[] names_of_algorithms) {
        this.names_of_algorithms = names_of_algorithms;
    }

    public JButton getComplete() {
        if ( complete == null ) {
            complete = new JButton ("ŞİFRELE");
            complete.setBounds(262, 360, 90, 30);
            this.add(complete);
        }
        return complete;
    }

    public void setComplete(JButton complete) {
        this.complete = complete;
    }

    public MovementsOnKeyboard getMov_key() {
        if ( mov_key == null ) {
//            mov_key = new MovementsOnKeyboard(this);
        }
        return mov_key;
    }

    public void setMov_key(MovementsOnKeyboard mov_key) {
        this.mov_key = mov_key;
    }

    public JPanel getReq_panel() {
        if ( req_panel == null ) {
            req_panel = new JPanel();
            req_panel.setBounds(500, 0,  130, 500);
            req_panel.setLayout(null);
            this.add(req_panel);
            JLabel entry_req = new JLabel ("GEREKSİNİMLER");
            entry_req.setBounds(5, 5, 100, 30);
            req_panel.add(entry_req);
        }
        return req_panel;
    }

    public void setReq_panel(JPanel req_panel) {
        this.req_panel = req_panel;
    }

    public Actions getAction() {
        if ( action == null ) {
            //action = new Actions (this);
        }
        return action;
    }

    public void setAction(Actions action) {
        this.action = action;
    }
    
    public void getReqofCeasar() { //EĞER CEASAR SEÇİLİRSE İNŞAELLAH REQ_PANEL E EKLENECEK ÖZELLİKLER
        JComboBox alphabets;
        SpinnerModel modelofshifts;
        JSpinner shifts;
        JLabel textofshift;
        Alphabet turkce, english;
        turkce = new Alphabet ((short) 29, "TÜRKÇE");
        english = new Alphabet ((short) 26, "ENGLISH");
        String[] alphs_names = {"TÜRKÇE", "ENGLISH"};
        alphabets = new JComboBox (alphs_names);
        alphabets.setBounds(5, 65, 90, 20);
        textofshift = new JLabel ("Kaydırma miktarı: ");
        textofshift.setBounds(5, 100, 115, 15);
        modelofshifts = new SpinnerNumberModel (1, 1, 26, 1);
        
        shifts = new JSpinner(modelofshifts);
        shifts.setBounds(35, 120, 40, 25);
        getReq_panel().add(alphabets);
        getReq_panel().add(shifts);
        getReq_panel().add(textofshift);
        
    }
    public void getReqofVigenere () {
        
    }
    public void getReqofPolybius () {
        
    }
    public void getReqofHill () {
        
    }
    public void getReqofColumnar () {
        
    }
    public void getReqofPicket_Fence () {
        
    }
    public void getReqofDES () {
        
    }
    public void getReqofAES () {
        
    }
    
}
